package Lib;
import java.util.Scanner;
import java.util.TreeSet;

import Lib.Bookdetails.Status;

public class Librarian 
{

	private static Scanner myObj;

	public static void main(String[] args)
	{
		
		
		
		TreeSet<Bookdetails> set = new TreeSet<Bookdetails>(new IdCom());
		set.add(new Bookdetails(1,"java","bala","MCA",Bookdetails.Status.taken,"nandha","sixth class","23/11/21"));
		set.add(new Bookdetails(2,"python","siva","MCA",Bookdetails.Status.available,null,null,null));
		set.add(new Bookdetails(3,"networking","bala","MCA",Bookdetails.Status.taken,"nandha","sixth class","23/11/21"));
		String username="nandha";
		String password="nan123";
		String username1="student";
		String password1="stud123";
		 System.out.println("welcome to login page....Enter User name & password");
		
		 myObj = new Scanner(System.in); 
		
		 
			System.out.println("Enter username");

		 
		 String uname=myObj.nextLine();
		 System.out.println("Enter the password");

		 String pw=myObj.nextLine();
		 System.out.println(set);
		 if(username.equals(uname) && password.equals(pw))
		 {
			 System.out.println("which operation are you like to perform 1.add 2.read  3.isempty 4.status check ");
			 Integer input=myObj.nextInt();
			 switch(input)
			 {
			 case 1:
				 System.out.println("how many records do u want to add");
				 Integer n=myObj.nextInt();
				 for(Integer i=0;i<n;i++)
				 {
					 System.out.println("Enter the Book id");

					 Integer bid = myObj.nextInt();
					 myObj.nextLine();
					 
					 System.out.println("Enter the Book name");

					  String bname = myObj.nextLine();
					 System.out.println("Enter the Book author name");

					  String author = myObj.nextLine();
					
					  myObj.nextLine();
					 System.out.println("Enter the Book department");

					  String dept = myObj.nextLine();
					  System.out.println("Enter the Book taker name");

					  String takenby = myObj.nextLine();
					  System.out.println("Enter the Book taker standard");

					  String std = myObj.nextLine();
					  System.out.println("Enter the Book taken date");

					  String date = myObj.nextLine();
					 
					  //System.out.println("Book id: "+bid+"Book name:  "+bname+"Author: "+author+"Quantity: "+quantity+"Department: "+dept);  
				 set.add(new Bookdetails(bid,bname,author,dept,Bookdetails.Status.available,takenby,std,date));
			
				 for(Bookdetails ele: set) 
			        { 
					 System.out.println("read the record");
			            System.out.println("Book id: "+ele.bid+"\nBook name:  "+ele.bname+"\n Author: "+ele.author+"\n Department: "+ele.dept+"\n Status: "+ele.status+"\n Book taker name: "+ele.takenby+"\n std: "+ele.std+"\ndate: "+ele.date); 
			            System.out.println(); 
			        } 
				 
				 				 
				 }
				 
				 break;
			 case 2:
				 System.out.println("read the record");
				
					 for(Bookdetails ele: set) 
					 {
						 System.out.println("read the record");
						 System.out.println("\n Book id: "+ele.bid+"\n Book name:  "+ele.bname+"\n Author: "+ele.author+"\n Department: "+ele.dept+"\n Status: "+ele.status+"\n Book taker name: "+ele.takenby+"\n std: "+ele.std+"\n date: "+ele.date); 
				            System.out.println(); 
					 }  
				 break;
			 case 3:
				 System.out.println("Checking record isempty or not and add it");
				 if(set.isEmpty())
				 {
				 System.out.println("how many records do u want to add");
				 Integer n1=myObj.nextInt();
				 for(Integer i=0;i<n1;i++)
				 {
					 System.out.println("Enter the Book id");

					 Integer bid = myObj.nextInt();
					 myObj.nextLine();
					 
					 System.out.println("Enter the Book name");

					  String bname = myObj.nextLine();
					 System.out.println("Enter the Book author name");

					  String author = myObj.nextLine();
					 
					  myObj.nextLine();
					  System.out.println("Enter the Book department");

					  String dept = myObj.nextLine();
					 System.out.println("Enter the Book taker name");

					  String takenby = myObj.nextLine();
					  System.out.println("Enter the Book taker standard");

					  String std = myObj.nextLine();
					  System.out.println("Enter the Book taken date");

					  String date = myObj.nextLine();
					 
					  //System.out.println("Book id: "+bid+"Book name:  "+bname+"Author: "+author+"Quantity: "+quantity+"Department: "+dept);  
				 set.add(new Bookdetails(bid,bname,author,dept,Bookdetails.Status.available,takenby,std,date));
			
				 for(Bookdetails ele: set) 
			        { 
					 System.out.println("read the record");
			            System.out.println("\n Book id: "+ele.bid+"\n Book name:  "+ele.bname+"\n Author: "+ele.author+"\n Department: "+ele.dept+"\n Status: "+ele.status+"\n Book taker name: "+ele.takenby+"\n std: "+ele.std+"\n date: "+ele.date); 
			            System.out.println(); 
			        } 
				 
				 }
				 }
				 else
				 {
					 System.out.println("no its not empty");
				 }
				 break;
				 
			 case 4:
				 System.out.println("Check particular record status with author and book name");
				 //System.out.println(" Enter author name ");
				 //Integer Fid = myObj.nextInt();
				 myObj.nextLine();
				 System.out.println("Enter  book name");
				 String Fname=myObj.nextLine();
				 for(Bookdetails ele: set) 
			        { 
					 if(ele.bname.equals(Fname))
					 {
						
							 System.out.println("Book available");
							 
								 System.out.println("read the record");
								 System.out.println("\n Book id: "+ele.bid+"\n Book name:  "+ele.bname+"\n Author: "+ele.author+"\n Department: "+ele.dept+"\n Status: "+ele.status+"\n Book taker name: "+ele.takenby+"\n std: "+ele.std+"\n date: "+ele.date); 
						            System.out.println(); 
						        
							
							
						 }
			        
						 
					 
			        
			 
					 else
					 {
						 System.out.println("Book not  available add it");
						 System.out.println("Enter the Book id");

						 Integer bid = myObj.nextInt();
						 myObj.nextLine();
						 
						 System.out.println("Enter the Book name");

						  String bname = myObj.nextLine();
						 System.out.println("Enter the Book author name");

						  String author = myObj.nextLine();
						 
						  myObj.nextLine();
						 System.out.println("Enter the Book department");

						  String dept = myObj.nextLine();
						  System.out.println("Enter the Book taker name");

						  String takenby = myObj.nextLine();
						  System.out.println("Enter the Book taker standard");

						  String std = myObj.nextLine();
						  System.out.println("Enter the Book taken date");

						  String date = myObj.nextLine();
						 
						  //System.out.println("Book id: "+bid+"Book name:  "+bname+"Author: "+author+"Quantity: "+quantity+"Department: "+dept);  
					 set.add(new Bookdetails(bid,bname,author,dept,Bookdetails.Status.available,takenby,std,date));
				
					 for(Bookdetails ele1: set) 
				        { 
						 System.out.println("read the record");
						 System.out.println("\n Book id: "+ele1.bid+"\n Book name:  "+ele1.bname+"\n Author: "+ele1.author+"\n Department: "+ele1.dept+"\n Status: "+ele1.status+"\n Book taker name: "+ele1.takenby+"\n std: "+ele1.std+"\n date: "+ele1.date); 
				            System.out.println(); 
				        } 
					 
					  
					 }}
					
			        break;    
			         
				
				 
			 default:
				 System.out.println("Invalid input");	
				 break;
			 }
			 
		 }
		   
			 
			
			 
//*****************USER PAGE CODE***********************************************************************************************************	 
	        
			 
		 else if(username1.equals(uname) && password1.equals(pw))
			 {
				 System.out.println("which operation are you like to perform  1.read 2. search");
				 Integer input3=myObj.nextInt();
			
				 System.out.println("welcom user");	 
				 
			switch(input3)
			{ 
			 case 1:
				 System.out.println("read the record");
				
					 for(Bookdetails ele: set) 
					 {
						 System.out.println("read the record");
						 System.out.println("\n Book id: "+ele.bid+"\n Book name:  "+ele.bname+"\n Author: "+ele.author+"\n Department: "+ele.dept+"\n Status: "+ele.status); 
				            System.out.println(); 
					 }  
				 break;
				 
			 case 2:
				 
				 System.out.println("Check particular record status with author and book name");
				 System.out.println(" Enter author name ");
				 String Fid1 = myObj.nextLine();
				 myObj.nextLine();
				 System.out.println("Enter  book name");
				 String Fname1=myObj.nextLine();
				 for(Bookdetails ele: set) 
			        { 
					 if(ele.author.equals(Fid1) && ele.bname.equals(Fname1))
					 {
						/* if(ele.status.equals(Status.available))
						 {
							 System.out.println("Book available");
							 
						 }*/
						 System.out.println("Book available");
						 
					 }
					 
			        }
					 
				 System.out.println("Book not available");
				 break;
				 default:
					 
					 System.out.println("invalid input");
					 break;
			}
			
			 }
		 else
		 {
		 
			 System.out.println("Incorrect password");	 
		 
		}
		 
		
	}
		 
		
		 

	}


