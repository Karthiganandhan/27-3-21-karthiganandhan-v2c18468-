package Lib;

class Bookdetails 
{
	public Integer bid;
	public String bname;
	public String author;
	
	public String dept;
	public Status status;
	public String takenby;
	public String std;
	public String date;
	enum Status 
    { 
        available,notavailable,taken
    }
	
	 public Bookdetails(Integer bid, String bname,String author,String dept,Status status,String takenby,String std,String date)
	  {
		  this.bid=bid;
		  this.bname=bname;
		  this.author=author;
		  
		  this.dept=dept;
		  this.status=status;
		  this.takenby=takenby;
		  this.std=std;
		  this.date=date;
	  }
	
	
		
	}
	


