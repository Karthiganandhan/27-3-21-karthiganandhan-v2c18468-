package Lib;

import java.util.Comparator;

class IdCom implements Comparator<Bookdetails> 
{ 
    
    public int compare(Bookdetails s1, Bookdetails s2)  
    { 
    	int s= s1.bid-s2.bid;
    	
       return s;
        
    } 
} 